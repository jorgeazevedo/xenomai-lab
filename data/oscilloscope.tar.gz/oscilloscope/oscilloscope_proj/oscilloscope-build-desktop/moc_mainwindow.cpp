/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created: Mon Nov 14 16:28:27 2011
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../oscilloscope_proj/mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x05,
      38,   11,   11,   11, 0x05,
      61,   11,   11,   11, 0x05,
      83,   11,   11,   11, 0x05,
      96,   11,   11,   11, 0x05,
     118,  116,   11,   11, 0x05,

 // slots: signature, parameters, type, tag, flags
     144,   11,   11,   11, 0x0a,
     162,   11,   11,   11, 0x0a,
     179,   11,   11,   11, 0x0a,
     197,   11,   11,   11, 0x0a,
     214,   11,   11,   11, 0x0a,
     233,   11,   11,   11, 0x0a,
     253,   11,   11,   11, 0x0a,
     271,   11,   11,   11, 0x0a,
     290,  116,   11,   11, 0x0a,
     312,  116,   11,   11, 0x0a,
     332,  116,   11,   11, 0x0a,
     350,  116,   11,   11, 0x0a,
     369,   11,   11,   11, 0x0a,
     393,   11,   11,   11, 0x0a,
     408,   11,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0sampPeriodChanged(double)\0"
    "timeDivChanged(double)\0ampDivChanged(double)\0"
    "forceReset()\0statusChanged(bool)\0,\0"
    "chColorChange(int,QColor)\0setampDiv(double)\0"
    "setChPos(double)\0setChGain(double)\0"
    "setChChoice(int)\0setChCoupling(int)\0"
    "setChColor(QString)\0setHorPos(double)\0"
    "setTimeDiv(double)\0setPeriod(int,double)\0"
    "setVMax(int,double)\0setVp(int,double)\0"
    "setVpp(int,double)\0setTriggerLevel(double)\0"
    "statusChange()\0callReset()\0"
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QWidget::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: sampPeriodChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 1: timeDivChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 2: ampDivChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 3: forceReset(); break;
        case 4: statusChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: chColorChange((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QColor(*)>(_a[2]))); break;
        case 6: setampDiv((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 7: setChPos((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 8: setChGain((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 9: setChChoice((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: setChCoupling((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: setChColor((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 12: setHorPos((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 13: setTimeDiv((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 14: setPeriod((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 15: setVMax((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 16: setVp((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 17: setVpp((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 18: setTriggerLevel((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 19: statusChange(); break;
        case 20: callReset(); break;
        default: ;
        }
        _id -= 21;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::sampPeriodChanged(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MainWindow::timeDivChanged(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void MainWindow::ampDivChanged(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void MainWindow::forceReset()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void MainWindow::statusChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void MainWindow::chColorChange(int _t1, QColor _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}
QT_END_MOC_NAMESPACE
